from distutils.core import setup

setup(
    name='HeikoEntropy',
    version='0.1.0',
    author='Heiko Balzter',
    author_email='hb'
)