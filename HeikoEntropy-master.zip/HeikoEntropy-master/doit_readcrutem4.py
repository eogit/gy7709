# -*- coding: utf-8 -*-
"""
Created on Sun Feb 12 22:20:21 2017

@author: heiko.balzter
"""

##############################################################################
#
# Import crutem4v temperature data and make plots and animated maps
#
##############################################################################

import numpy as np
import numpy.ma as ma
from scipy.io import netcdf
from skimage import data, io, filters
import matplotlib.pyplot as plt
import matplotlib as matplotlib
import imageio #to make a movie loop
from os import listdir
from os.path import isfile, join
from copy import copy, deepcopy
io.use_plugin('matplotlib')
# import the MSE module
from pymse import PyMSE
# import the linear regression model and plot functions
from scipy import stats
import pylab
# import the nonlinear regression model and plot functions
from scipy.optimize import curve_fit
from scipy import optimize
# import image visualisation
from scipy import ndimage
from scipy import misc
# I downloaded a basemap version for python 3.6 from http://www.lfd.uci.edu/~gohlke/pythonlibs/
import mpl_toolkits
from mpl_toolkits.basemap import Basemap

# set working direcory
wd = 'C:\\Users\\localadmin1\\Desktop\\pythonhb\\'

# define data input file
crutemfile = wd+'CRUTEM4v.5.0.0.txt'

# set options
monthlymaps = True # create global maps for each month?
yearlymaps = True  # create global maps for each year?
plottrends = True  # create graphics files showing whether trends are present in the chunks of data

#define the nonlinear model
def func(t, A, K, C):
    return A * np.exp(-K*t) + C

def fit_exp_nonlinear(t, y):
    opt_parms, parm_cov = optimize.curve_fit(func, t, y, maxfev=15000)
    A, K, C = opt_parms
    return A, K, C

#define functions to read/write floating point numbers from/to a text file
def read_floats(filename):
    with open(filename) as f:
        return [float(x) for x in f]
    f.close()

def write_floats(data, filename):
    file = open(filename, 'w')
    for item in data:
        file.write("%f\n" % item)
    file.close()

#define a plotting function for the maps
def do_plot(image, file, title, tmin, tmax):
    plt.figure(figsize=(12.0, 9.0),dpi=150)
    plt.title(title)
    plt.subplot(1, 1, 1)
    io.imshow(image, cmap=plt.cm.jet, vmin=tmin, vmax=tmax), plt.savefig(file, figsize=(12.0, 9.0),dpi=150)
    plt.close()

# define a plotting function to make a global map
# masking out all values < -99
def do_worldmap(image, lat, lon, parallels, meridians, file, title, zlim):
    # image = 2D array
    # lat, lon = arrays of latitude / longitude coordinates (same dimensions as image)
    # parallels = vector of parralels to be drawn, e.g. np.arange(-90., 99., 30.)
    # meridians = vector of meridians, e.g. np.arange(-180., 180., 60.) 
    # file = filename including path
    # title = title string for map
    # zlim = min and max values for color scale [zmin,zmax]
    masked_image = ma.masked_less(image, -99)
    fig = plt.figure()
    ax = fig.add_axes([0.05,0.05,0.9,0.9])
    # if coastlines not used, set resolution to None to skip continent processing (this speeds things up a bit)
    mymap = Basemap(projection='kav7',lon_0=0,resolution='c')
    # color background of map projection region. Missing values over land will show up this color.
    mymap.drawmapboundary(fill_color="#7777ff")
    # mymap.fillcontinents(color='slategrey',lake_color='royalblue', alpha=1)
    mymap.drawlsmask(land_color = "chocolate", ocean_color="cornflowerblue", resolution = 'i')
            #land_color = "#ddaa66", ocean_color="#7777ff", resolution = 'l')
    #mymap.bluemarble()
    im1 = mymap.pcolormesh(lon, lat, masked_image, shading='flat', cmap=plt.cm.jet, vmin=zlim[0], vmax=zlim[1], latlon=True)
    mymap.drawparallels(parallels, linewidth=0.5)
    mymap.drawmeridians(meridians, linewidth=0.5)
    cb = mymap.colorbar(im1,"bottom", size="5%", pad="2%")
    ax.set_title(title)
    mymap.drawcoastlines(linewidth=0.5, color='white')
    mymap.drawcountries(linewidth=0.5, color='white'), pylab.savefig(file, figsize=(12.0, 9.0), dpi=300)
    fig.clf()
    
# read in the lat/long grid coordinates
f = netcdf.netcdf_file(wd+'CRUTEM.4.5.0.0.variance_adjusted.nc', 'r')
print(f.title)
print(f.version)
print(f.institution)
print(f.reference)
print(f.dimensions)
lat = f.variables['latitude']
lon = f.variables['longitude']
print(lat.units)
print(lat.shape)
print(lon.units)
print(lon.shape)
print(lat[:])
print(lon[:])
f.close()

# set commmon mapping parameters for Basemap
mylon, mylat = np.meshgrid(lon[:],lat[:]) # make a matrix of lat, lon coordinates
mylat = np.flipud(mylat)
parallels = np.arange(-90., 99., 30.)
meridians = np.arange(-180., 180., 60.)

# This gets the lat/long coordinates of all grid boxed.
# Trouble is, I cannot see the temperature anomaly values
# So, read the crutem4v text file:
# One line of header data, with year, month, number 1 (what does that mean?), etc.
# Example: ' 1850 1 1 36 rows 72 columns. Missing=-1.000e+30 Version=CRUTEM.4.5.0.0 Field_status=f'
# Followed by 72 floating point numbers for row i, so 36 blocks of 72 numbers.
# BADC advises: The CRU TS3.0 data are stored in both ASCII and NetCDF formats:
#   ASCII data: The 360-lat x 720-long grid is presented exactly as that, with 720 columns, and 360 rows per timestep.
#   The first row in each grid is the southernmost (centred on 89.75S). 
#   The first column is the westernmost (centred on 179.75W).    

#open the text file
f = open(crutemfile, 'r')

# create a variable with the temperature anomaly data (variance adjusted) with years, months, 36 rows and 72 columns
nt=(2017-1850)*12 # number of time steps = n years * 12 months
crutem4v = np.zeros((nt, 36, 72),dtype=float)

#read in each line
row = 0 #counts the data blocks of 72 values per row
print('Reading data file: '+crutemfile)
for line in f:
    line = line.strip() #remove \n
    columns = line.split() #split string into words
    if float(columns[0]) > 1800: #test whether we have reached a header line
        year = int(columns[0])
        month = int(columns[1])
        row = 0 #reset row counter
    else:
        t = [float(x) for x in columns] #convert list of strings to list of floats, with temperatures for 72 columns of one row
        ti = (year-1850)*12 + month-1 #time index for array
        crutem4v[ti,row,:] = t
        row = row+1 #next row
f.close()
 
# missing vales are coded -1e+30
na = -1e+30

# determine overall lowest and highest values as a common color scale
print('Original data:')
# mask out NaN and zero values
mask = np.logical_not(np.logical_or(crutem4v < -99.0, crutem4v == 0.))
tmp = deepcopy(crutem4v[mask])
tmin = tmp.min()
tmax = tmp.max()
print('NA = '+str(na)+'    Min = '+str(tmin)+'    Max = '+str(tmax))
hist, binedges = np.histogram(tmp, bins=50, range=(tmin,tmax))
bincentres = binedges[0:len(binedges)-1] + (binedges[1]-binedges[0])/2
my_xticks = str(bincentres)
plt.xticks(bincentres, my_xticks)
plt.plot(bincentres, hist)
plt.show()
plt.close()

# cut off the extreme ends of the distribution based on 1% and 99% quantiles
for p in range(0,100):
    print(str(p+0.5)+'% percentile = '+str(np.percentile(tmp,p+0.5)))
print('\n')
p1 = np.percentile(tmp, 0.5)
p2 = np.percentile(tmp, 99.5)
print('0.5% percentile = '+str(p1))
print('99.5% percentile = '+str(p2))
crutperc = deepcopy(crutem4v)
mask = crutperc == 0.
crutperc[mask] = na
mask = crutperc < -999
crutperc[mask] = -999
mask = np.logical_and(crutperc > -998, crutperc < p1)
crutperc[mask] = p1
mask = crutperc > p2
crutperc[mask] = p2
nadisp = (p1 - 0.5) // 1 #set a value for missing values (NA) to optimise display

# determine overall lowest and highest values as a common color scale
print('Data after masking out the 0.5% and 99.5% percentiles:')
# mask out NaN and zero values
mask = np.logical_not(np.logical_or(crutperc < -99., crutperc == 0.))
tmp = crutperc[mask]
tmin = tmp.min()
tmax = tmp.max()
print('NA = '+str(na)+'    Min = '+str(tmin)+'    Max = '+str(tmax))
hist, binedges = np.histogram(tmp, bins=50, range=(tmin,tmax))
bincentres = binedges[0:len(binedges)-1] + (binedges[1]-binedges[0])/2
my_xticks = str(bincentres)
plt.xticks(bincentres, my_xticks)
plt.plot(bincentres, hist)
plt.show()
plt.close()

#now make maps for all months
if monthlymaps:
    mypath = wd+'crutem4v_maps_monthly\\'
    zlim = [p1,p2] # common color scale
    for year in range(1850,2017):
        print(year)
        for month in range(1,13):
            ti = (year-1850)*12 + month-1 #time index for array
            file = mypath+'crutem4v_map_'+str(year)+'_'+str(month)+'.tif'
            title = 'CRUTEM4v '+str(month)+' '+str(year)
            image = crutperc[ti,:,:]
            do_worldmap(image, mylat, mylon, parallels, meridians, file, title, zlim)
    # make a movie of all monthly maps
    imagestack = []
    filenames = [f for f in listdir(mypath) if isfile(join(mypath, f))]
    for filename in filenames:
        imagestack.append(imageio.imread(mypath+filename))
    kargs = { 'duration': 0.1, 'loop': 1, 'subrectangles': True}
    imageio.mimsave(wd+'crutem4vmovie_monthly.gif', imagestack, **kargs)
    # mimsave options:
    #    Parameters for saving
    #    ---------------------
    #    loop : int
    #        The number of iterations. Default 0 (meaning loop indefinitely).
    #    duration : {float, list}
    #        The duration (in seconds) of each frame. Either specify one value
    #        that is used for all frames, or one value for each frame.
    #    fps : float
    #        The number of frames per second. If duration is not given, the
    #        duration for each frame is set to 1/fps. Default 10.
    #    palettesize : int
    #        The number of colors to quantize the image to. Is rounded to
    #        the nearest power of two. Default 256.
    #    subrectangles : bool
    #        If True, will try and optimize the GIF by storing only the
    #        rectangular parts of each frame that change with respect to the
    #        previous. Default False.
    
# now make maps for all years (averages)
# N.B. missing values will be masked out
if yearlymaps:
    mypath = wd+'crutem4v_maps_annual\\'
    zlim = [p1,p2] # common color scale
    for year in range(1850,2016):
        print(year)
        file = mypath+'crutem4v_map_'+str(year)+'.tif'
        image = []
        n = [] # map of the number of zeros per grid cell over one year
        for month in range(1,13):
            ti = (year-1850)*12 + month-1 #time index for array
            imagem = crutperc[ti,:,:]
            if month==1: 
                image=deepcopy(imagem)
                n = 1*(image < -99) # returns 1 for cells with values < -99 and 0 otherwise
            else:
                image = image+imagem
                n = n + 1*(image < -99) 
        image=image/(12-n)
        title = 'CRUTEM4v '+str(year)
        do_worldmap(image, mylat, mylon, parallels, meridians, file, title, zlim)
    # make a movie of all monthly maps
    imagestack = []
    filenames = [f for f in listdir(mypath) if isfile(join(mypath, f))]
    for filename in filenames:
        imagestack.append(imageio.imread(mypath+filename))
    kargs = { 'duration': 0.1, 'subrectangles': True}
    imageio.mimsave(wd+'crutem4vmovie_yearly.gif', imagestack, loop=1, **kargs)

##############################################################################
#
# Multi-scale entropy analysis of temperature data for each grid box
#
##############################################################################

# set options: define the maximum scale factor, the tolerance r and the pattern length m
maxscale = 60
r=0.4
m=3

# define number of timeseries subsets and minimum length to be included in analysis
nchnks=2
minlen=500

# define color palette
cols = list(['black','red','blue','green', 'magenta','purple','brown'])

# loop over all grid boxes
tmax = (2015-1850)*12 + 12-1 # maximum time index for array, here set to December 2015
msestack = np.zeros([36,72,2,maxscale]) # store the results of MSE for each grid box and chunk
predict_msestack = np.zeros([36,72,2,maxscale])
for row in range(0,36):
    for col in range(0,72):
        # Pull out the time series data for this grid box
        ts = np.array(crutem4v[:,row,col])
        x = range(0,len(ts))
        st0 = 0
        st1 = 0
        #####################################################################
        # Missing value removal
        #####################################################################
        # Check for missing values in the time series
        #mask = (ts < -999)
        #if sum(1*mask) > 0:
        #    print('Missing values are being removed.') 
        # treat missing values
        # split the time series into two chunks
        for ch in range(0,nchnks):
            #chunk 1 is 1850-1960, i.e. 111 years * 12 months of data
            if ch == 0:
                st = 0*12
                en = 111*12
            #chunk 2 is 1961-2015, i.e. 55 years * 12 months of data
            if ch == 1:
                st = 111*12
                en = 111*12+55*12
            ti1 = -99 # find the first time index from which on no more missing values are found
            for ti in range(en,st,-1):
                subset = ts[ti:en]
                if (sum(1*(subset < -999)) == 0):
                    ti1 = ti # remember the time index position
                    tsusable = ts[ti1:en]
            # check whether time series chunk is 'good for analysis', i.e. has at least minglength values
            if ch == 0:
                len0 = len(tsusable)
                st0 = st
                tsgood0 = (ti1 > -99) and (len0 > minlen)
                ts0 = tsusable
            if ch == 1:
                len1 = len(tsusable)
                st1 = st
                tsgood1 = (ti1 > -99) and (len1 > minlen)
                ts1 = tsusable
        tsgood = tsgood0 and tsgood1

        # plot the original time series data and the trend line if significant
        # note that we will continue to use the original data in the MSE analysis
        # and not the detrended data, because we do not want to change the variances
        if plottrends and tsgood:
            file = wd + 'crutem4v_mse\\plots\\crutem4v_trends_R'+str(row+1)+'_C'+str(col+1)
            title = 'CRUTEM4v, R='+str(row+1)+' C='+str(col+1)
            plt.figure(figsize=(12.0, 9.0),dpi=150)
            f, axarr = plt.subplots(2, 2)
            plt.title(title)
            # trend analysis
            x0 = range(st0,len(ts0))
            x1 = range(st1,st1+len(ts1))
            slope0, intercept0, r_value0, p_value0, std_err0 = stats.linregress(x0,ts0)
            slope1, intercept1, r_value1, p_value1, std_err1 = stats.linregress(x1,ts1)
            axarr[0, 0].set_title('Time series TS0')
            axarr[0, 0].plot(x0, ts0, '.k', ms=2)
            if p_value0 < 0.05:
                pred0 = intercept0 + slope0 * x0
                axarr[0, 0].plot(x0, pred0, '-r')
                dts0 = ts0 - pred0
            else:
                dts0 = ts0
            axarr[1, 0].set_title('Detrended TS0')
            axarr[1, 0].plot(x0, dts0, '.k', ms=2)
            axarr[0, 1].set_title('Time series TS1')
            axarr[0, 1].plot(x1, ts1, '.k', ms=2)
            if p_value1 < 0.05:
                pred1 = intercept1 + slope1 * x1
                axarr[0, 1].plot(x1, pred1, '-r')
                dts1 = ts1 - pred1
            else:
                dts0 = ts1
            axarr[1, 1].set_title('Detrended TS1')
            axarr[1, 1].plot(x1, dts1, '.k', ms=2)
            # Fine-tune figure; hide x ticks for top plots and y ticks for right plots
            plt.setp([a.get_xticklabels() for a in axarr[0, :]], visible=False)
            plt.setp([a.get_yticklabels() for a in axarr[:, 1]], visible=False), plt.savefig(file, figsize=(12.0, 9.0),dpi=150)
            plt.close()
        
        # write the chunks to a separate text file only if both chunks are good
        if tsgood is True:
            write_floats(ts0, wd+'crutem4v_mse\\data\\crutem4v_ts_'+str(row+1)+'_'+str(col+1)+'_1.txt')
            write_floats(ts1, wd+'crutem4v_mse\\data\\crutem4v_ts_'+str(row+1)+'_'+str(col+1)+'_2.txt')
            
        # If time series chunks are not good for analysis, print a message
        if tsgood is False:
            print('Row '+str(row+1)+' Col '+str(col+1)+' excluded from analysis.  n='+str(len(ts)-2*maxscale)+'   length 0 = '+str(len0)+'   length 1 = '+str(len1))

        # If time series chunks are good for analysis, go to MSE calculations
        else:
            print('MSE analysis of Row '+str(row+1)+' Col '+str(col+1)+'.  n='+str(len(ts)-2*maxscale)+'   length 0 = '+str(len0)+'   length 1 = '+str(len1))

            # split the time series into two chunks
            for ch in range(0,nchnks):

                #read in the chunk into PyMSE
                ts = PyMSE(wd+'crutem4v_mse\\data\\crutem4v_ts_'+str(row+1)+'_'+str(col+1)+'_'+str(ch+1)+'.txt')

                # coarsegraining
                ts.data_cg

                # calculate the sample entropy, for r,std,scale_factor
                mse = np.zeros([maxscale,])

                for i in range(0, maxscale):
                    #calculate MSE for a given r, standard deviation, scale factor
                    sd=np.std(ts.data)
                    # get the sample entropy parameters into the object
                    ts.get(scale=i+1,m=m,r=r)
                    mse[i]=ts.sample_entropy(r, sd, i+1)[0] 
    
                # Fit the exponential model, but mask out any SE values greater than 2 (outliers where no pattern matches were found)
                x = np.arange(1,maxscale+1,dtype=float)
                y = mse
                ################################################################
                # remove SE outliers from the model fitting where SE > 2
                ################################################################
                # A, K, C = fit_exp_nonlinear(x,y) # with all data points
                A, K, C = fit_exp_nonlinear(x[y<2],y[y<2]) # SE > 2 removed
                predict_mse = func(x, A, K, C)
        
                #Calculate prediction error
                residuals = mse - predict_mse
                fres = sum(residuals**2)
    
                #save results to text file
                np.savetxt(wd+'crutem4v_mse\\mse\\crutem4v_mse_'+str(row+1)+'_'+str(col+1)+'_'+str(ch+1)+'.txt', np.column_stack((x, mse, predict_mse, residuals)), delimiter='\t')
    
                # save MSE plot to graphics file
                file = wd+'crutem4v_mse\\mse\\crutem4v_mse_'+str(row+1)+'_'+str(col+1)+'_'+str(ch+1)+'.tif'
                fig1 = pylab.figure(figsize=(12.0, 9.0),dpi=150) # The size of the figure is specified as (width, height) in inches
                fig1 = pylab.plot(x, mse, 'ok')
                fig1 = pylab.plot(x, mse, '--g')
                fig1 = pylab.ylim([0,1.05*max(list(mse))])
                pylab.xlabel('scale factor')
                pylab.ylabel('SE')
                fig1 = pylab.title(('CRUTEM4v, R%d C%d, part=%d, r=%4.2f, m=%d, sd=%4.2f') % (row+1,col+1,ch+1,r,m,sd))
                fig1 = pylab.plot(x, predict_mse, 'k-'), pylab.savefig(file,figsize=(12.0, 9.0),dpi=150)
                
                plt.figure(figsize=(12.0, 9.0),dpi=150)
                
                #keep MSE estimates for later
                msestack[row,col,ch,:] = mse
                predict_msestack[row,col,ch,:] = predict_mse
            
            # Here, we end the loop over all chunks and restart it again in order to overlay MSE plots of chunks 1 and 2
            ymax = 1.05 * msestack.max() # set a common y axis range
            ypredmax = 1.05 * predict_msestack.max() # set a common y axis range

            # save MSE plots with predicted models for all chunks in one figure
            file = wd+'crutem4v_mse\\plots\\crutem4v_mse_'+str(row+1)+'_'+str(col+1)+'_all.tif'
            fig1 = pylab.figure(figsize=(12.0, 9.0),dpi=150) # The size of the figure is specified as (width, height) in inches
            for ch in range(0,nchnks):
                fig1 = pylab.plot(x, msestack[row,col,ch,:], 'o', color=cols[ch], label = 'TS'+str(ch))
                fig1 = pylab.plot(x, msestack[row,col,ch,:], '--', color=cols[ch])
                fig1 = pylab.plot(x, predict_msestack[row,col,ch,:], '-', color=cols[ch])
            fig1 = pylab.ylim([0,ymax])
            pylab.legend()
            pylab.xlabel('scale factor')
            pylab.ylabel('SE')
            fig1 = pylab.title(('CRUTEM4v, R%d C%d, r=%4.2f, m=%d, sd=%4.2f') % (row+1,col+1,r,m,sd)), pylab.savefig(file,figsize=(12.0, 9.0),dpi=150)
            
            # save model results to graphics file
            file = wd+'crutem4v_mse\\plots\\crutem4v_mse_'+str(row+1)+'_'+str(col+1)+'_all_models.tif'
            fig1 = pylab.figure(figsize=(12.0, 9.0),dpi=150) # The size of the figure is specified as (width, height) in inches
            for ch in range(0,nchnks):
                fig1 = pylab.plot(x, predict_msestack[row,col,ch,:], '-', color=cols[ch], label = 'TS'+str(ch))
            fig1 = pylab.ylim([0,ypredmax])
            pylab.legend()
            pylab.xlabel('scale factor')
            pylab.ylabel('SE')
            fig1 = pylab.title(('CRUTEM4v, R%d C%d, r=%4.2f, m=%d, sd=%4.2f') % (row+1,col+1,r,m,sd)), pylab.savefig(file,figsize=(12.0, 9.0),dpi=150)
    
            # save MSE anomaly plot to graphics file, with chunk 0 being the baseline
            file = wd+'crutem4v_mse\\plots\\crutem4v_mse_'+str(row+1)+'_'+str(col+1)+'_anomalies.tif'
            fig1 = pylab.figure(figsize=(12.0, 9.0),dpi=150) # The size of the figure is specified as (width, height) in inches
            for ch in range(1,nchnks):
                fig1 = pylab.plot(x, msestack[row,col,ch,:] - msestack[row,col,0,:], 'o', color=cols[ch], label = 'TS'+str(ch))
                fig1 = pylab.plot(x, msestack[row,col,ch,:] - msestack[row,col,0,:], '--', color=cols[ch])
            pylab.legend()
            pylab.xlabel('scale factor')
            pylab.ylabel('SE anomaly')
            fig1 = pylab.plot([0,maxscale], [0,0], 'k', linestyle='dotted')
            fig1 = pylab.title(('CRUTEM4v, R%d C%d, r=%4.2f, m=%d, sd=%4.2f') % (row+1,col+1,r,m,sd)), pylab.savefig(file,figsize=(12.0, 9.0),dpi=150)
            
            # now do the next column, then the next row

# save the array with the MSE results to file
file = wd+'crutem4v_mse\\data\\msestack.npy'
np.save(file, msestack)
# save the array with the crutem4v data to file
file = wd+'crutem4v_mse\\data\\crutem4v.npy'
np.save(file, crutem4v)
# save the array with the tidied up CRUTPERC data to file
file = wd+'crutem4v_mse\\data\\crutperc.npy'
np.save(file, crutperc)

##############################################################################
#
# Make global maps of MSE results
#
##############################################################################

# open datasets
# read the array with the MSE results from file
file = wd+'crutem4v_mse\\data\\msestack.npy'
msestack = np.load(file)
# read the array with the crutem4v data from file
file = wd+'crutem4v_mse\\data\\crutem4v.npy'
crutem4v = np.load(file)
# read the array with the tidied up CRUTPERC data from file
file = wd+'crutem4v_mse\\data\\crutperc.npy'
crutperc = np.load(file)

# 1. Make a map of the scale factor that shows the biggest change from TS1 to TS2
msechange = ma.asarray(msestack[:,:,1,:] - msestack[:,:,0,:])
# mask out all grid cells where at least one of the chunks has zero value
msechange.mask = ma.mask_or(msestack[:,:,1,:] == 0, msestack[:,:,0,:] == 0)
# mask out spurious values (greater difference in SE than +- 2)
msechange.mask = ma.mask_or(msechange.mask, msechange < -2)
msechange.mask = ma.mask_or(msechange.mask, msechange > 2)
# find maximum absolute change values over all scale factors for each grid cell
msechangemax = msechange.max(axis=2)
msechangemin = msechange.min(axis=2)
mapdata = ma.copy(msechangemax)
mapdata[msechangemax > abs(msechangemin)] = msechangemax[msechangemax > abs(msechangemin)]
mapdata[msechangemax <= abs(msechangemin)] = msechangemin[msechangemax <= abs(msechangemin)]
file = wd+'crutem4v_mse\\plots\\map_magn_of_maxSEchange.tif'
title = 'Largest change in SE'
z = max(mapdata.min(), mapdata.max(), key=abs)
zlim = -z, z
do_worldmap(mapdata, mylat, mylon, parallels, meridians, file, title, zlim)
        
# 2. Make a map of the magnitude of the biggest change in SE for that scale factor
# Map shows the magnitude of the largest change in sample entropy detected across all scale factors 
# Negative values show a decrease of SE from 1850–1960 to 1961–2014. 
# Only statistically significant change is shown
scalefacmax = np.argmax(msechange, axis=2) # find locations of maximum values over all scale factors for each grid cell
scalefacmin = np.argmin(msechange, axis=2) # find locations of minimum values over all scale factors for each grid cell
mapdata = ma.copy(scalefacmax)
mapdata[msechangemax > abs(msechangemin)] = scalefacmax[msechangemax > abs(msechangemin)]
mapdata[msechangemax <= abs(msechangemin)] = scalefacmin[msechangemax <= abs(msechangemin)]
mapdata = ma.asarray(mapdata)
mapdata.mask = msechangemax.mask
file = wd+'crutem4v_mse\\plots\\map_scalefactor_of_maxSEchange.tif'
title = 'Scale factor with biggest change in SE'
zlim = 0, mapdata.max()
do_worldmap(mapdata, mylat, mylon, parallels, meridians, file, title, zlim)
              
##############################################################################
#
# the rest is just some playing around with images
#
##############################################################################
# test with a racoon
f = misc.face()
plt.imshow(f)
plt.show()
# now draw a line through the image
plt.imshow(f)
x=[0,1000]
y=[750,0]
plt.plot(x,y,'-w', linewidth=3)
plt.show()

# test with a stored image file
#g = misc.imread(wd+'crutem4v_map_2015_1.tif') # uses the Image module (PIL)
#plt.imshow(g)
#plt.show()

# Tip: For large data, use np.memmap for memory mapping:
# face_memmap = np.memmap('face.raw', dtype=np.uint8, shape=(768, 1024, 3))
#  
#for i in range(10):
#    im = np.random.random_integers(0, 255, 10000).reshape((100, 100))
#    misc.imsave('random_%02d.png' % i, im)
#from glob import glob
#filelist = glob('random*.png')
#filelist.sort()

    # file = wd+'tmp.tif'
    # io.imshow(crutperc[1500,:,:], cmap=plt.cm.jet, vmin=tmin, vmax=tmax), plt.savefig(file, figsize=(8.0, 6.0), dpi=72)


#map = Basemap(resolution ='c')
#map.drawcoastlines()
#map.drawcountries()
#map.drawmeridians(np.arange(0, 360, 30))
#map.drawparallels(np.arange(-90, 90, 30))
#map.bluemarble()
#lat_list=worksheet.col_values(16)
#long_list=worksheet.col_values(17)
#lat_list.remove('lat')
#long_list.remove('lon')
#for index in range(0,len(lat_list)):
#    x, y = map(long_list[index],lat_list[index])
#    map.plot(x, y, 'bo', markersize=5)
